# -*- coding: utf-8 -*-
## Declaración de las Estaciones meteorológicas de AEMET
estaciones =["C029O",
             "C038N",
             "C048W",
             "C117A",
             "C117Z",
             "C126A",
             "C129Z",
             "C139E",
             "C148F",
             "C229X", #Por norma general, no hay datos en la web AEMET para esta estación
             "C239N",
             "C248E",
             "C249I",
             "C258K",
             "C259X",
             "C314Z",
             "C315P",
             "C317B",
             "C319W",
             "C328W",
             "C329Z",
             "C406G",
             "C419X",
             "C428T",
             "C429I",
             "C430E",
             "C438N",
             "C446G",
             "C447A",
             "C449C",
             "C449F",
             "C457I",
             "C458A",
             "C459Z",
             "C468B",
             "C469N",
             "C611E",
             "C612F",
             "C619X",
             "C619Y",
             "C623I",
             "C625O",
             "C628B",
             "C629Q", #Por norma general, no hay datos en la web AEMET para esta estación
             "C629X",
             "C635B",
             "C639M",
             "C639U",
             "C648C",
             "C648N",
             "C649I",
             "C649R",
             "C656V",
             "C658X",
             "C659H",
             "C659M",
             "C669B",
             "C689E",
             "C916Q",
             "C925F",
             "C929I",
             "C939T",
             "C019V",
             "C028K", #Por norma general, no hay datos en la web AEMET para esta estación
             "C029R", #Por norma general, no hay datos en la web AEMET para esta estación
             "C129V",
             "C329B",
             "C619B", #Por norma general, no hay datos en la web AEMET para esta estación
             "C619D", #Por norma general, no hay datos en la web AEMET para esta estación
             "C619I", #Por norma general, no hay datos en la web AEMET para esta estación
             "C629I", #Por norma general, no hay datos en la web AEMET para esta estación
             "C658L", #Por norma general, no hay datos en la web AEMET para esta estación
             "C665I", #Por norma general, no hay datos en la web AEMET para esta estación
             "C665T",
             "C668V", #Por norma general, no hay datos en la web AEMET para esta estación
             "C839I", #Por norma general, no hay datos en la web AEMET para esta estación
             "C839X",
             "C917E",
             "C919K", #Por norma general, no hay datos en la web AEMET para esta estación
             "C639Y"]  #Por norma general, no hay datos en la web AEMET para esta estación
